$(function(){
  var mySwiper = new Swiper('.swiper-container',{
    autoplay: 3000,
    loop: true,
  // slidesPerView: 1,
  // freeMode: true,
})
});
