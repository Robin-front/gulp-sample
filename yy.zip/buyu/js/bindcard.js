$(function(){
  $('.J_bindcard').submit(function(){
    var $this = $(this);


  });

  $(".J_bindcard").citySelect({prov:"湖南", city:"长沙"});
});
